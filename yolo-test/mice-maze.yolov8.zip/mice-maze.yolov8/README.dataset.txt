# Mice Maze > 2024-07-21 11:59am
https://universe.roboflow.com/mice-maze/mice-maze

Provided by a Roboflow user
License: Public Domain

